
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns


class DynamicEDA:
    def __init__(self, data: pd.DataFrame):
        """
        Initialize the DynamicEDA class with the given dataset.

        Args:
            data (pd.DataFrame): The input dataset for EDA.
        """
        self.data = data
        self.columns = self.data.columns

    def check_missing_values(self):
        """
        Check and print the missing values in the dataset.
        """
        missing_values = self.data.isnull().sum()
        print("\nMissing Values:")
        print(missing_values)

    def summary_statistics(self):
        """
        Generate summary statistics for the dataset.
        """
        print("\nDataset Summary:")
        print(self.data.describe())

    def plot_distribution(self, column: str):
        """
        Plot the distribution of a specific column.

        Args:
            column (str): The column name to plot the distribution for.
        """
        plt.figure(figsize=(10, 6))
        sns.histplot(self.data[column], bins=30, kde=True, color='blue')
        plt.title(f'Distribution of {column}')
        plt.xlabel(column)
        plt.ylabel('Frequency')
        plt.show()

    def plot_boxplot(self, column: str, hue: str = None):
        """
        Plot a boxplot for a given column, optionally segmented by hue.

        Args:
            column (str): The column name to plot the boxplot for.
            hue (str, optional): The column name to use for hue (categorical variable).
        """
        plt.figure(figsize=(10, 6))
        sns.boxplot(x=hue, y=column, data=self.data, palette='coolwarm') if hue else sns.boxplot(y=self.data[column], color='skyblue')
        plt.title(f'Boxplot of {column}')
        plt.xlabel('Category' if hue else column)
        plt.ylabel(column)
        plt.show()

    def plot_correlation_heatmap(self, correlation_columns: list = None):
        """
        Plot a correlation heatmap for numerical columns.

        Args:
            correlation_columns (list, optional): List of columns to include in the correlation matrix. 
                                                  If None, it will use all numeric columns.
        """
        if correlation_columns is None:
            correlation_columns = self.data.select_dtypes(include=np.number).columns
        correlation_matrix = self.data[correlation_columns].corr()
        plt.figure(figsize=(10, 8))
        sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', fmt='.2f')
        plt.title('Correlation Heatmap')
        plt.show()

    def plot_invoice_status_distribution(self, status_col: str):
        """
        Plot the distribution of invoice status.

        Args:
            status_col (str): The column name representing the invoice status.
        """
        plt.figure(figsize=(10, 6))
        status_counts = self.data[status_col].value_counts()
        sns.barplot(x=status_counts.index, y=status_counts.values, palette='viridis')
        plt.title(f'{status_col} Distribution')
        plt.xlabel('Status')
        plt.ylabel('Count')
        plt.show()

    def plot_monthly_total_amounts(self, date_column: str, amount_column: str):
        """
        Plot total amounts by month.

        Args:
            date_column (str): The column representing the invoice date.
            amount_column (str): The column representing the amount.
        """
        self.data[date_column] = pd.to_datetime(self.data[date_column])
        monthly_data = self.data.groupby(self.data[date_column].dt.to_period('M'))[amount_column].sum()
        plt.figure(figsize=(12, 6))
        monthly_data.plot(kind='bar', color='skyblue')
        plt.title(f'Monthly {amount_column} Amounts')
        plt.xlabel('Month')
        plt.ylabel(amount_column)
        plt.xticks(rotation=45)
        plt.show()

    def plot_top_customers(self, customer_col: str, amount_col: str, top_n: int = 10):
        """
        Plot the top N customers by total amount.

        Args:
            customer_col (str): The column containing customer names.
            amount_col (str): The column containing the total amount.
            top_n (int, optional): The number of top customers to display. Default is 10.
        """
        top_customers = self.data.groupby(customer_col)[amount_col].sum().sort_values(ascending=False).head(top_n)
        plt.figure(figsize=(10, 6))
        sns.barplot(x=top_customers.values, y=top_customers.index, palette='mako')
        plt.title(f'Top {top_n} Customers by Total Amount')
        plt.xlabel('Total Amount')
        plt.ylabel('Customer Name')
        plt.show()

    def plot_invoice_count_over_time(self, date_column: str, invoice_col: str):
        """
        Plot the number of invoices over time.

        Args:
            date_column (str): The column containing the invoice issue date.
            invoice_col (str): The column containing the invoice ID.
        """
        self.data[date_column] = pd.to_datetime(self.data[date_column])
        invoice_count = self.data.groupby(self.data[date_column].dt.to_period('M'))[invoice_col].count()
        plt.figure(figsize=(12, 6))
        invoice_count.plot(kind='line', marker='o', color='green')
        plt.title('Invoice Count Over Time')
        plt.xlabel('Month')
        plt.ylabel('Number of Invoices')
        plt.grid()
        plt.show()


def main():
    """
    Main function to run dynamic EDA on the dataset.
    """
    # Load data
    file_path = r'C:\Users\Dhananjay R\stg_a_invoices_202411191822.csv'
    data = pd.read_csv(file_path)

    # Initialize the DynamicEDA class
    eda = DynamicEDA(data)

    # Perform dynamic EDA
    eda.check_missing_values()
    eda.summary_statistics()

    # Plot various EDA visualizations
    eda.plot_distribution('total_amt')
    eda.plot_boxplot('total_amt')
    eda.plot_correlation_heatmap()
    eda.plot_invoice_status_distribution('status')
    eda.plot_monthly_total_amounts('inv_issue_dt', 'total_amt')
    eda.plot_top_customers('cust_name', 'total_amt', top_n=5)
    eda.plot_invoice_count_over_time('inv_issue_dt', 'invoice_id')


if __name__ == '__main__':
    main()
