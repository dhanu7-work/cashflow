# # main.py
# import pickle

# # Load the framework from the pickle file
# with open('sarima_model.pkl', 'rb') as f:
#     SARIMAForecasting = pickle.load(f)

# # Initialize the SARIMA forecasting model
# sarima = SARIMAForecasting(order=(1, 1, 1), seasonal_order=(1, 1, 1, 12))

# # Load the dataset
# monthly_data = sarima.load_data(
#     file_path=r'C:\\Users\\Akshat Singh\\Chello_PLAID\\transactions_single_account.csv',
#     date_column='transaction_date',
#     target_column='expenses',
#     test_size=2
# )

# # Check stationarity
# sarima.check_stationarity(monthly_data['expenses'])

# # Train the model
# sarima.train_model(target_column='expenses')

# # Forecast and evaluate
# sarima.forecast(steps=2)
# evaluation = sarima.evaluate(target_column='expenses')
# print(f"Evaluation Metrics: {evaluation}")

# # Plot the results
# sarima.plot_results(target_column='expenses')

import sys
import os
import pickle
from sarima_framework_expense_monthly import SARIMAForecastingMonthly
import pandas as pd

# Add the config folder path to sys.path
config_path = os.path.join(os.path.dirname(__file__), 'config')
sys.path.append(config_path)

# Import the configuration
from config import CONFIG_sarima_expense_monthly

def run_pipeline(config):
    # Initialize the SARIMA forecasting model
    forecasting = SARIMAForecastingMonthly(
        order=config['sarima_order'], 
        seasonal_order=config['seasonal_order']
    )

    # Load and preprocess data
    data = forecasting.load_data(
        config['data_path'], 
        config['date_col'], 
        config['target_col'], 
        test_size=config['test_size']
    )

    # Check stationarity
    forecasting.check_stationarity(data[config['target_col']])

    # Train the model
    forecasting.train_model(config['target_col'])

    # Save the trained model
    with open(config['model_save_path'], 'wb') as f:
        pickle.dump(forecasting, f)
    print(f"Model saved at {config['model_save_path']}")

    # Forecast and evaluate
    forecast_results, conf_int = forecasting.forecast(steps=config['test_size'])
    metrics = forecasting.evaluate(config['target_col'])
    print("Evaluation Metrics:", metrics)

    # Plot the forecast results
    forecasting.plot_results(config['target_col'])

    # Save forecast comparison to CSV
    comparison_df = pd.DataFrame({
        'Actual': forecasting.test[config['target_col']],
        'Predicted': forecast_results,
        'Lower_CI': conf_int.iloc[:, 0],
        'Upper_CI': conf_int.iloc[:, 1]
    })

    comparison_file = config['forecast_comparison_save_path']
    comparison_df.to_csv(comparison_file, index=False)
    print(f"Forecast comparison results saved to {comparison_file}")

if __name__ == '__main__':
    run_pipeline(CONFIG_sarima_expense_monthly)
