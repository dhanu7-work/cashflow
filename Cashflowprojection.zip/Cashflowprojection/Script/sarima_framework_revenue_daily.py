import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import pickle
from statsmodels.tsa.statespace.sarimax import SARIMAX
from statsmodels.tsa.stattools import adfuller
from sklearn.metrics import mean_absolute_error, mean_squared_error
import os

class SARIMAForecasting:
    def __init__(self, order=(1, 1, 1), seasonal_order=(1, 1, 1, 7)):
        self.order = order
        self.seasonal_order = seasonal_order
        self.model = None
        self.train = None
        self.test = None
        self.forecast_results = None
        self.conf_int = None

    def load_data(self, file_path, date_column, target_column, test_size):
        data = pd.read_csv(file_path)
        data[date_column] = pd.to_datetime(data[date_column])
        data.set_index(date_column, inplace=True)
        self.train = data.iloc[:-test_size]
        self.test = data.iloc[-test_size:]
        return data

    def check_stationarity(self, timeseries):
        result = adfuller(timeseries, autolag='AIC')
        print(f'ADF Statistic: {result[0]}')
        print(f'p-value: {result[1]}')
        print('Stationary' if result[1] < 0.05 else 'Non-Stationary')

    def train_model(self, target_column):
        self.model = SARIMAX(self.train[target_column], order=self.order, seasonal_order=self.seasonal_order)
        self.fitted_model = self.model.fit(disp=False)
        return self.fitted_model

    def forecast(self, steps):
        forecast = self.fitted_model.get_forecast(steps=steps)
        self.forecast_results = forecast.predicted_mean
        self.conf_int = forecast.conf_int()
        return self.forecast_results, self.conf_int

    def evaluate(self, target_column):
        actual = self.test[target_column]
        mae = mean_absolute_error(actual, self.forecast_results)
        mse = mean_squared_error(actual, self.forecast_results)
        rmse = np.sqrt(mse)
        test_nonzero = actual[actual != 0]
        mape = np.mean(np.abs((test_nonzero - self.forecast_results[test_nonzero.index]) / test_nonzero)) * 100

        return {
            'MAE': mae,
            'MSE': mse,
            'RMSE': rmse,
            'MAPE': mape
        }

    def plot_results(self, target_column):
        actual = self.test[target_column]
        plt.figure(figsize=(14, 7))
        plt.plot(self.train.index, self.train[target_column], label='Training Data', color='blue')
        plt.plot(actual.index, actual, label='Testing Data (Actual)', color='orange')
        plt.plot(self.forecast_results.index, self.forecast_results, label='Forecast', color='red', linestyle='--')
        plt.fill_between(self.conf_int.index, self.conf_int.iloc[:, 0], self.conf_int.iloc[:, 1], 
                         color='green', alpha=0.3, label='Confidence Interval')
        plt.title("SARIMA Forecast vs Actuals with Confidence Intervals")
        plt.xlabel("Date")
        plt.ylabel("Amount (in dollars)")
        plt.legend()
        plt.grid()
        plt.show()



# Get the directory where the script is located
script_dir = os.path.dirname(os.path.abspath(__file__))
model_dir = os.path.join(script_dir, 'models')

# Ensure the models directory exists
os.makedirs(model_dir, exist_ok=True)

# Save the SARIMA model
model_file_path = os.path.join(model_dir, 'sarima_model.pkl')
with open(model_file_path, 'wb') as f:
    pickle.dump(SARIMAForecasting, f)














    