import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

def load_data(file_path):
    """Load data from a CSV file."""
    df = pd.read_csv(file_path)
    df['Date'] = pd.to_datetime(df['Date'], format='%Y-%m-%d')  # Convert 'Date' to datetime using the correct format
    return df

def categorize_data(df):
    """Categorize data into income and expenses."""
    df['Amount'] = df['Balance']  # Create a new column for Amount based on Balance
    df['Type'] = df['Category Status'].apply(lambda x: 'Expense' if x == 'Expense' else 'Income')
    return df

import pandas as pd
import matplotlib.pyplot as plt

# Function to plot income vs expenses with parameterized columns
def plot_income_vs_expenses(
    df, 
    date_col='Date', 
    type_col='Type', 
    amount_col='Amount', 
    title='Income vs Expenses Over Time', 
    x_label='Date', 
    y_label='Amount (USD)', 
    legend_title='Type', 
    bar_color='viridis', 
    figsize=(12, 6), 
    rotation=45
):
    """
    Plot income vs expenses with customizable parameters.

    Parameters:
    - df: DataFrame containing the data
    - date_col: Column name for dates
    - type_col: Column name for types (e.g., income/expenses)
    - amount_col: Column name for amounts
    - title: Plot title
    - x_label: X-axis label
    - y_label: Y-axis label
    - legend_title: Legend title
    - bar_color: Color palette for the bars
    - figsize: Figure size
    - rotation: Rotation angle for X-axis labels
    """
    # Group and summarize data
    summary = df.groupby([date_col, type_col])[amount_col].sum().unstack().fillna(0)

    # Plot the results
    plt.figure(figsize=figsize)
    summary.plot(kind='bar', stacked=True, colormap=bar_color)
    plt.title(title)
    plt.xlabel(x_label)
    plt.ylabel(y_label)
    plt.xticks(rotation=rotation)
    plt.legend(title=legend_title)
    plt.tight_layout()
    plt.show()

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Function to plot expenses by category with parameters
def plot_category_expenses(
    df, 
    type_col='Type', 
    expense_type='Expense', 
    category_col='Level 1 Name', 
    amount_col='Amount', 
    title='Total Expenses by Category', 
    x_label='Expense Category', 
    y_label='Total Amount (USD)', 
    bar_color='viridis', 
    figsize=(10, 6), 
    rotation=45
):
    """
    Plot expenses by category with customizable parameters.

    Parameters:
    - df: DataFrame containing the data
    - type_col: Column name indicating the type of transaction
    - expense_type: Value representing expenses in the type_col
    - category_col: Column name for expense categories
    - amount_col: Column name for expense amounts
    - title: Plot title
    - x_label: X-axis label
    - y_label: Y-axis label
    - bar_color: Color palette for the bars
    - figsize: Figure size
    - rotation: Rotation angle for X-axis labels
    """
    # Filter and summarize expenses
    expense_summary = df[df[type_col] == expense_type].groupby(category_col)[amount_col].sum().reset_index()

    # Plot the results
    plt.figure(figsize=figsize)
    sns.barplot(x=category_col, y=amount_col, data=expense_summary, palette=bar_color)
    plt.title(title)
    plt.xlabel(x_label)
    plt.ylabel(y_label)
    plt.xticks(rotation=rotation)
    plt.tight_layout()
    plt.show()

def calculate_insights(df):
    """Calculate insights from the profit and loss data."""
    insights = {
        "Total Income": df[df['Type'] == 'Income']['Amount'].sum(),
        "Total Expenses": df[df['Type'] == 'Expense']['Amount'].sum(),
        "Net Profit/Loss": df[df['Type'] == 'Income']['Amount'].sum() - df[df['Type'] == 'Expense']['Amount'].sum(),
        "Total Unique Categories": df['Level 1 Name'].nunique(),
        "Total Transactions": len(df)
    }
    return insights

import pandas as pd
import matplotlib.pyplot as plt

# Function to analyze missing data with parameterized columns
def analyze_missing_data(
    data, 
    columns_label='Columns', 
    missing_values_label='Number of Missing Values', 
    figsize=(12, 6), 
    title='Missing Data Analysis', 
    plot_file='missing_data_analysis.png', 
    bar_color='skyblue'
):
    """
    Analyze and visualize missing data in the dataset.

    Parameters:
    - data: DataFrame to analyze
    - columns_label: X-axis label for columns
    - missing_values_label: Y-axis label for missing values
    - figsize: Size of the plot
    - title: Title of the plot
    - plot_file: Name of the file to save the plot
    - bar_color: Color for the bars
    """
    # Calculate missing data
    missing_data = data.isnull().sum()

    # Convert to DataFrame for better customization
    missing_df = pd.DataFrame({
        columns_label: missing_data.index, 
        missing_values_label: missing_data.values
    })

    # Plot missing data
    plt.figure(figsize=figsize)
    plt.bar(missing_df[columns_label], missing_df[missing_values_label], color=bar_color)
    plt.title(title)
    plt.xlabel(columns_label)
    plt.ylabel(missing_values_label)
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()
    plt.close()

def main(file_path):
    # Load the data
    df = load_data(file_path)

    analyze_missing_data(
    df, 
    columns_label='Dataset Columns', 
    missing_values_label='Count of Missing Data', 
    title='Missing Values Analysis by Column', 
    bar_color='orange'
)

    # Categorize the data
    df = categorize_data(df)

    # Plot income vs expenses
    plot_income_vs_expenses(
    df, 
    date_col='Transaction Date', 
    type_col='Category', 
    amount_col='Transaction Amount', 
    title='Monthly Cash Flow Overview', 
    x_label='Transaction Date', 
    y_label='Total Amount (USD)', 
    legend_title='Category Type', 
    bar_color='coolwarm', 
    figsize=(10, 5), 
    rotation=30
)

    # Plot expenses by category
    plot_category_expenses(
    df, 
    type_col='Transaction Type', 
    expense_type='Expense', 
    category_col='Expense Category', 
    amount_col='Transaction Amount', 
    title='Expenses Breakdown by Category', 
    x_label='Category of Expense', 
    y_label='Total Expense Amount (USD)', 
    bar_color='coolwarm', 
    figsize=(10, 5), 
    rotation=30
)

    # Calculate and print insights
    insights = calculate_insights(df)
    print("Insights:")
    for key, value in insights.items():
        print(f"{key}: {value:.2f}")


# Replace with your actual file path
file_path = r'C:\Users\Dhananjay R\OneDrive - Zillion Technologies Inc\Downloads\CodatData\CodatData\profit_loss_combined.csv'
main(file_path)
