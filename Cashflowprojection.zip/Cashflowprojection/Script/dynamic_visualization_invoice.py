import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Function to load and preprocess the dataset
def load_data(file_path):
    df = pd.read_csv(file_path)
    df.columns = df.columns.str.strip().str.lower()  # Clean column names
    return df

# Function to clean and convert date columns
def clean_dates(df, date_columns):
    for date_col in date_columns:
        df[date_col] = pd.to_datetime(df[date_col], errors='coerce')
    return df

def plot_column_distribution(df, column_name, title="Column Distribution", xlabel="Categories", ylabel="Count", figsize=(8, 4), colors=None):
    """
    Function to plot the distribution of a given column in a DataFrame.

    Parameters:
        df (pd.DataFrame): The DataFrame containing the data.
        column_name (str): The name of the column to analyze.
        title (str): The title of the plot.
        xlabel (str): The label for the x-axis.
        ylabel (str): The label for the y-axis.
        figsize (tuple): Figure size as (width, height).
        colors (list): List of colors for the bars. Defaults to None.
    """
    plt.figure(figsize=figsize)
    df[column_name].value_counts().plot(kind='bar', color=colors)
    plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.show()


import pandas as pd
import matplotlib.pyplot as plt

# Function to plot monthly invoicing trends with parameterized columns
def plot_monthly_invoicing_trend(
    df, 
    issue_date_col='issue date', 
    invoice_id_col='invoice id', 
    current_month_col='current_month', 
    number_of_invoices_col='number_of_invoices',
    x_label='Month', 
    y_label='Number of Invoices', 
    title='Monthly Invoices Issued'
):
    """
    Plot monthly invoicing trends with customizable columns and labels.

    Parameters:
    - df: DataFrame containing the data
    - issue_date_col: Column name for the issue date
    - invoice_id_col: Column name for the invoice ID
    - current_month_col: Name to assign for the month period column
    - number_of_invoices_col: Name to assign for monthly invoice counts
    - x_label: Label for the X-axis
    - y_label: Label for the Y-axis
    - title: Title of the plot
    """
    # Extract month from issue date
    df[current_month_col] = df[issue_date_col].dt.to_period('M')
    
    # Group by month and count invoices
    monthly_invoices = df.groupby(current_month_col)[invoice_id_col].count().reset_index()
    monthly_invoices.rename(columns={invoice_id_col: number_of_invoices_col}, inplace=True)

    # Plot the monthly trend
    plt.figure(figsize=(10, 6))
    plt.plot(
        monthly_invoices[current_month_col].astype(str), 
        monthly_invoices[number_of_invoices_col], 
        marker='o', color='blue'
    )
    plt.title(title)
    plt.xlabel(x_label)
    plt.ylabel(y_label)
    plt.xticks(rotation=45)
    plt.grid(True, linestyle='--', alpha=0.6)
    plt.show()



import pandas as pd
import matplotlib.pyplot as plt

# Function to plot top customers by revenue with parameterized columns
def plot_top_customers(
    df, 
    customer_col='customer company name', 
    revenue_col='total amount', 
    top_n=10, 
    customer_label='Customer', 
    revenue_label='Total Revenue (USD)', 
    title_prefix='Top'
):
    """
    Plot top customers by revenue with customizable columns and labels.

    Parameters:
    - df: DataFrame containing the data
    - customer_col: Column name for customer company name
    - revenue_col: Column name for total revenue
    - top_n: Number of top customers to plot
    - customer_label: Label for the X-axis
    - revenue_label: Label for the Y-axis
    - title_prefix: Prefix for the plot title
    """
    # Group by customer and sum revenue
    top_customers = df.groupby(customer_col)[revenue_col].sum().sort_values(ascending=False).head(top_n)

    # Plot the results
    plt.figure(figsize=(10, 6))
    top_customers.plot(kind='bar', color='purple')
    plt.title(f'{title_prefix} {top_n} {customer_label}s by {revenue_label}')
    plt.xlabel(customer_label)
    plt.ylabel(revenue_label)
    plt.xticks(rotation=45)
    plt.grid(axis='y', linestyle='--', alpha=0.7)
    plt.show()


import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Function to plot payment lag distribution with parameterized columns and labels
def plot_payment_lag(
    df, 
    paid_date_col='paid on date', 
    due_date_col='due date', 
    lag_days_col='payment lag', 
    title='Payment Lag Distribution (in days)', 
    xlabel='Days of Payment Lag', 
    ylabel='Frequency', 
    color='green', 
    bins=20, 
    kde=True
):
    """
    Plot payment lag distribution with customizable columns and labels.

    Parameters:
    - df: DataFrame containing the data
    - paid_date_col: Column name for the paid date
    - due_date_col: Column name for the due date
    - lag_days_col: Name of the calculated lag column
    - title: Plot title
    - xlabel: Label for the X-axis
    - ylabel: Label for the Y-axis
    - color: Histogram color
    - bins: Number of histogram bins
    - kde: Whether to show KDE plot
    """
    # Calculate payment lag in days
    df[lag_days_col] = (df[paid_date_col] - df[due_date_col]).dt.days.fillna(0)

    # Create the plot
    plt.figure(figsize=(8, 4))
    sns.histplot(df[lag_days_col], bins=bins, kde=kde, color=color)
    plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.grid(axis='y', linestyle='--', alpha=0.7)
    plt.show()


# Function to plot customer contribution to total revenue (pie chart)
# def plot_customer_contribution(df):
#     total_revenue_per_customer = df.groupby('customer company name')['total amount'].sum()

#     plt.figure(figsize=(8, 8))
#     total_revenue_per_customer.plot(kind='pie', autopct='%1.1f%%', startangle=90, cmap='Set2')
#     plt.title('Customer Contribution to Total Revenue')
#     plt.ylabel('')
#     plt.show()

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Function to plot invoice amount distribution with parameterized columns and labels
def plot_invoice_amount_distribution(
    df, 
    amount_col='total amount', 
    title='Invoice Amount Distribution', 
    xlabel='Invoice Total Amount (USD)', 
    ylabel='Frequency', 
    color='orange', 
    bins=30, 
    kde=True
):
    """
    Plot invoice amount distribution with customizable columns and labels.

    Parameters:
    - df: DataFrame containing the data
    - amount_col: Column name for the invoice amount
    - title: Plot title
    - xlabel: Label for the X-axis
    - ylabel: Label for the Y-axis
    - color: Histogram color
    - bins: Number of histogram bins
    - kde: Whether to show KDE plot
    """
    plt.figure(figsize=(8, 4))
    sns.histplot(df[amount_col], bins=bins, kde=kde, color=color)
    plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.grid(axis='y', linestyle='--', alpha=0.7)
    plt.show()


# Main function to execute all visualizations
def visualize_invoices(file_path, date_columns):
    # Load data
    df = load_data(file_path)

    # Clean date columns
    df = clean_dates(df, date_columns)

    analyze_missing_data(df)

    # Generate visualizations
    
    plot_monthly_invoicing_trend(
    df, 
    issue_date_col='issue date', 
    invoice_id_col='invoice id', 
    current_month_col='current_month', 
    number_of_invoices_col='monthly_invoice_count', 
    x_label='Month', 
    y_label='Invoices Count', 
    title='Monthly Invoices Overview'
)
    plot_top_customers(
    df, 
    customer_col='customer company name', 
    revenue_col='total amount', 
    top_n=5, 
    customer_label='Client', 
    revenue_label='Total Sales (USD)', 
    title_prefix='Highest Revenue Generating'
)
    plot_payment_lag(
    df, 
    paid_date_col='paid on date', 
    due_date_col='due date', 
    lag_days_col='days_late', 
    title='Custom Payment Lag Distribution',
    xlabel='Days Late',
    ylabel='Number of Payments',
    color='purple',
    bins=15,
    kde=True
)
    
    plot_invoice_amount_distribution(
    df, 
    amount_col='invoice_amount', 
    title='Custom Invoice Amount Distribution',
    xlabel='Total Invoice Amount (USD)',
    ylabel='Count of Invoices',
    color='blue',
    bins=20,
    kde=True
)
    
    analyze_missing_data(
    df ,  
    columns_label='Dataset Columns', 
    missing_label='Count of Missing Entries', 
    title='Custom Missing Data Report',
    color='coral',
    figsize=(10, 5)
)



import pandas as pd
import matplotlib.pyplot as plt

# Function to analyze missing data with parameterized labels
def analyze_missing_data(
    data, 
    columns_label='Columns', 
    missing_label='Number of Missing Values', 
    title='Missing Data Analysis', 
    color='skyblue', 
    figsize=(12, 6)
):
    """
    Analyze missing data in the dataset with customizable labels.

    Parameters:
    - data: DataFrame containing the data
    - columns_label: Custom label for X-axis (columns)
    - missing_label: Custom label for Y-axis (missing values count)
    - title: Plot title
    - color: Color of the bar plot
    - figsize: Figure size
    """
    missing_data = data.isnull().sum()

    plt.figure(figsize=figsize)
    missing_data.plot(kind='bar', color=color)
    plt.title(title)
    plt.xlabel(columns_label)
    plt.ylabel(missing_label)
    plt.grid(axis='y', linestyle='--', alpha=0.7)
    plt.tight_layout()
    plt.show()


# Call the main function
if __name__ == "__main__":
    file_path = r'C:\Users\Dhananjay R\OneDrive - Zillion Technologies Inc\Downloads\CodatData\CodatData\invoices.csv'
    date_columns = ['issue date', 'due date', 'paid on date']  # Specify the date columns
    visualize_invoices(file_path, date_columns)
    
    

