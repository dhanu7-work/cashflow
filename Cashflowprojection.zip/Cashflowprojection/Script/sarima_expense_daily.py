# import pickle

# # Load the SARIMA forecasting framework
# with open('sarima_model.pkl', 'rb') as f:
#     SARIMAForecasting = pickle.load(f)

# # Initialize the SARIMA model
# sarima_model = SARIMAForecasting(order=(1, 1, 1), seasonal_order=(1, 1, 1, 7))

# # Load data
# data = sarima_model.load_data(
#     file_path='C:\\Users\\Akshat Singh\\Chello_PLAID\\transactions_single_account.csv',
#     date_column='transaction_date',
#     target_column='expenses',
#     test_size=45
# )

# # Check stationarity
# sarima_model.check_stationarity(data['expenses'])

# # Train the model
# sarima_model.train_model(target_column='expenses')

# # Forecast and evaluate
# sarima_model.forecast(steps=45)
# metrics = sarima_model.evaluate(target_column='expenses')

# # Print evaluation metrics
# for key, value in metrics.items():
#     print(f"{key}: {value:.2f}")

# # Plot the results
# sarima_model.plot_results(target_column='expenses')

from sarima_framework_expense_daily import SARIMAForecasting
import sys
import os
import pickle

# Add the config folder path to sys.path
config_path = os.path.join(os.path.dirname(__file__), 'config')
sys.path.append(config_path)

# Now import the CONFIG dictionary
from config import CONFIG_sarima_expense_daily 


def run_pipeline(config):
    # Initialize and run SARIMA model
    forecasting = SARIMAForecasting(
        order=config['sarima_order'], 
        seasonal_order=config['seasonal_order']
    )

    # Load data
    data = forecasting.load_data(
        config['data_path'], 
        config['date_col'], 
        config['target_col'], 
        config['test_size']
    )

    # Check stationarity
    forecasting.check_stationarity(data[config['target_col']])

    # Train model
    forecasting.train_model(config['target_col'])

    # Save model
    with open(config['model_save_path'], 'wb') as f:
        pickle.dump(forecasting, f)
    print(f"Model saved at {config['model_save_path']}")

    # Forecast and evaluate
    forecast_results, conf_int = forecasting.forecast(steps=config['test_size'])
    metrics = forecasting.evaluate(config['target_col'])

    print("Evaluation Metrics:", metrics)

    # Plot results
    forecasting.plot_results(config['target_col'])


if __name__ == '__main__':
    run_pipeline(CONFIG_sarima_expense_daily)
