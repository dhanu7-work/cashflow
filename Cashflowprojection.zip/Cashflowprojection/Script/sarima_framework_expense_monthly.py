# SARIMAFramework.py
import pandas as pd
import numpy as np
import pickle
import matplotlib.pyplot as plt
from statsmodels.tsa.statespace.sarimax import SARIMAX
from statsmodels.tsa.stattools import adfuller
from sklearn.metrics import mean_absolute_error, mean_squared_error
import os

class SARIMAForecastingMonthly:
    def __init__(self, order, seasonal_order):
        self.order = order
        self.seasonal_order = seasonal_order
        self.model = None
        self.results = None
        self.train = None
        self.test = None
        self.forecast_mean = None
        self.forecast_ci = None

    def load_data(self, file_path, date_column, target_column, test_size):
        data = pd.read_csv(file_path)
        data[date_column] = pd.to_datetime(data[date_column])
        data.set_index(date_column, inplace=True)
        monthly_data = data.resample('M').sum().reset_index()
        monthly_data.rename(columns={date_column: 'month'}, inplace=True)
        self.train = monthly_data.iloc[:-test_size]
        self.test = monthly_data.iloc[-test_size:]
        return monthly_data

    def check_stationarity(self, timeseries):
        result = adfuller(timeseries, autolag='AIC')
        print(f'ADF Statistic: {result[0]}')
        print(f'p-value: {result[1]}')
        print('Stationary' if result[1] < 0.05 else 'Non-Stationary')

    def train_model(self, target_column):
        self.model = SARIMAX(self.train[target_column], order=self.order, seasonal_order=self.seasonal_order)
        self.results = self.model.fit(disp=False)

    def forecast(self, steps):
        try:
        # Generate forecast
            forecast = self.results.get_forecast(steps=steps)
            
            # Get predicted mean and confidence intervals
            self.forecast_mean = forecast.predicted_mean
            self.forecast_ci = forecast.conf_int()

            # Ensure that the test index is available for indexing
            if hasattr(self, 'test') and self.test is not None:
                if len(self.forecast_mean) == len(self.test):
                    self.forecast_mean.index = self.test.index
                    self.forecast_ci.index = self.test.index
                else:
                    print("Warning: Length mismatch between forecast and test data. Index assignment skipped.")
            else:
                print("Warning: 'self.test' is not defined or has no valid index. Index assignment skipped.")

            # Return forecast mean and confidence intervals
            return self.forecast_mean, self.forecast_ci

        except Exception as e:
            print(f"Error during forecasting: {e}")
            return None, None


    def evaluate(self, target_column):
        mae = mean_absolute_error(self.test[target_column], self.forecast_mean)
        mse = mean_squared_error(self.test[target_column], self.forecast_mean)
        return {'MAE': mae, 'MSE': mse}

    def plot_results(self, target_column):
        plt.figure(figsize=(14, 7))
        plt.plot(self.train['month'], self.train[target_column], label='Training Data', color='blue')
        plt.plot(self.test['month'], self.test[target_column], label='Testing Data (Actual)', color='orange')
        plt.plot(self.forecast_mean, label='Forecast', color='red', linestyle='--')
        plt.fill_between(self.forecast_ci.index, self.forecast_ci.iloc[:, 0], self.forecast_ci.iloc[:, 1], 
                         color='green', alpha=0.3, label='Confidence Interval (Min-Max)')
        plt.title("Forecast vs Actuals with Confidence Intervals for Monthly Expenses")
        plt.xlabel("Date")
        plt.ylabel("Amount (in dollars)")
        plt.legend()
        plt.grid()
        plt.show()

# Get the directory where the script is located
script_dir = os.path.dirname(os.path.abspath(__file__))
model_dir = os.path.join(script_dir, 'models')

# Ensure the models directory exists
os.makedirs(model_dir, exist_ok=True)

# Save the SARIMA model
model_file_path = os.path.join(model_dir, 'sarima_model_expense_monthly.pkl')
with open(model_file_path, 'wb') as f:
    pickle.dump(SARIMAForecastingMonthly, f)
