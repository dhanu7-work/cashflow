import psycopg2
import pandas as pd

def connect_to_database(host, database, user, password):
    """ Establish a connection to the PostgreSQL database. """
    try:
        connection = psycopg2.connect(
            host=host, database=database, user=user, password=password
        )
        return connection
    except Exception as e:
        print(f"Error connecting to database: {e}")
        return None


def fetch_data(connection, schema, table, limit=10):
    """ Fetch data from a specified schema and table with a limit. """
    query = f"SELECT * FROM {schema}.{table} LIMIT {limit};"
    try:
        df = pd.read_sql(query, connection)
        return df
    except Exception as e:
        print(f"Error fetching data from {table}: {e}")
        return pd.DataFrame()


def main():
    # Database connection details
    db_config = {
        "host": "chellodb.cluster-cb8gwiek2g7m.us-east-2.rds.amazonaws.com",
        "database": "postgres",
        "user": "chellodb",
        "password": "ChelloDB123",
    }

    # Table details
    tables = [
        {"schema": "layera_staging", "table": "stg_a_invoices"},
        {"schema": "layera_staging", "table": "stg_a_payments"},
    ]

    # Establish database connection
    connection = connect_to_database(**db_config)
    if not connection:
        return

    try:
        # Fetch data dynamically
        data_frames = {}
        for tbl in tables:
            df = fetch_data(connection, tbl['schema'], tbl['table'])
            table_name = f"{tbl['schema']}_{tbl['table']}"
            data_frames[table_name] = df
            print(f"Fetched {len(df)} records from {table_name}.")

        # Merge data
        combined_df = pd.merge(
            data_frames['layera_staging_stg_a_invoices'],
            data_frames['layera_staging_stg_a_payments'],
            on='cust_id',
            how='inner'
        )

        # Save to CSV
        output_file = 'output.csv'
        combined_df.to_csv(output_file, index=False)
        print(f"Data saved to {output_file}.")

    finally:
        connection.close()

if __name__ == "__main__":
    main()
