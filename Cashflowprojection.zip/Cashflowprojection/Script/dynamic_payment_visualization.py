import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

def load_data(file_path):
    """Load data from a CSV file."""
    df = pd.read_csv(file_path)
    df['Payment Date'] = pd.to_datetime(df['Payment Date'])
    return df

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Function to plot total payments by customer with parameterized labels
def plot_total_payments_by_customer(
    df, 
    customer_col='Customer Company Name', 
    amount_col='Total Amount', 
    title='Total Payments by Customer', 
    x_label='Customer Company Name', 
    y_label='Total Amount (USD)', 
    color_palette='viridis', 
    figsize=(10, 6),
    rotation=45
):
    """
    Plot total payments by customer with customizable labels.

    Parameters:
    - df: DataFrame containing the data
    - customer_col: Column representing customers
    - amount_col: Column representing payment amounts
    - title: Plot title
    - x_label: Label for X-axis
    - y_label: Label for Y-axis
    - color_palette: Seaborn color palette
    - figsize: Figure size
    - rotation: Rotation angle for X-axis labels
    """
    # Summarize data by customer
    customer_summary = df.groupby(customer_col).agg({amount_col: 'sum'}).reset_index()

    # Create the plot
    plt.figure(figsize=figsize)
    sns.barplot(x=customer_col, y=amount_col, data=customer_summary, palette=color_palette)
    plt.title(title)
    plt.xlabel(x_label)
    plt.ylabel(y_label)
    plt.xticks(rotation=rotation)
    plt.tight_layout()
    plt.show()

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Function to plot payments over time with parameterized labels
def plot_payments_over_time(
    df, 
    date_col='Payment Date', 
    amount_col='Total Amount', 
    title='Payments Over Time', 
    x_label='Payment Date', 
    y_label='Total Amount (USD)', 
    line_color='b', 
    marker_style='o', 
    figsize=(12, 6), 
    rotation=45
):
    """
    Plot payments over time with customizable labels.

    Parameters:
    - df: DataFrame containing the data
    - date_col: Column representing payment dates
    - amount_col: Column representing payment amounts
    - title: Plot title
    - x_label: Label for X-axis
    - y_label: Label for Y-axis
    - line_color: Line color for the plot
    - marker_style: Marker style for points on the line
    - figsize: Figure size
    - rotation: Rotation angle for X-axis labels
    """
    # Create the plot
    plt.figure(figsize=figsize)
    sns.lineplot(x=date_col, y=amount_col, data=df, marker=marker_style, color=line_color)
    plt.title(title)
    plt.xlabel(x_label)
    plt.ylabel(y_label)
    plt.xticks(rotation=rotation)
    plt.tight_layout()
    plt.show()

def calculate_insights(df, customer_col='Customer Company Name', amount_col='Total Amount', method_col='Account Name'):
    """Calculate insights from the payment data."""
    insights = {
        "Total Unique Customers": df[customer_col].nunique(),
        "Total Payments Made": df[amount_col].sum(),
        "Average Payment Amount": df[amount_col].mean(),
        "Payment Methods Used": df[method_col].unique()
    }
    return insights

import pandas as pd
import matplotlib.pyplot as plt

# Function to analyze missing data with parameterized labels
def analyze_missing_data(
    data, 
    columns_label='Columns', 
    missing_values_label='Number of Missing Values', 
    title='Missing Data Analysis', 
    bar_color='skyblue', 
    figsize=(12, 6), 
    rotation=45
):
    """
    Analyze missing data with customizable labels and columns.

    Parameters:
    - data: DataFrame containing the data
    - columns_label: Custom label for the X-axis (column names)
    - missing_values_label: Custom label for the Y-axis (missing values count)
    - title: Plot title
    - bar_color: Color of the bars in the plot
    - figsize: Figure size
    - rotation: Rotation angle for X-axis labels
    """
    # Calculate missing data
    missing_data = data.isnull().sum()

    # Plot missing data
    plt.figure(figsize=figsize)
    missing_data.plot(kind='bar', color=bar_color)
    plt.title(title)
    plt.xlabel(columns_label)
    plt.ylabel(missing_values_label)
    plt.xticks(rotation=rotation)
    plt.tight_layout()
    plt.show()
    plt.close()

def main(file_path):
    # Load the data
    df = load_data(file_path)
    analyze_missing_data(df)
    # Plot total payments by customer
    plot_total_payments_by_customer(df)

    # Plot payments over time
    plot_payments_over_time(df)

    # Calculate and print insights
    insights = calculate_insights(df)
    print("Insights:")
    for key, value in insights.items():
        print(f"{key}: {value}")

# Replace with your actual file path
file_path = r'C:\Users\Dhananjay R\OneDrive - Zillion Technologies Inc\Downloads\CodatData\CodatData\payments.csv'
main(file_path)
