# import pickle
# from sarima_framework_revenue_daily import SARIMAForecasting


# # Load the framework
# with open('models/sarima_model.pkl', 'rb') as f:
#     SARIMAForecasting = pickle.load(f)

# Initialize and run
# forecasting = SARIMAForecasting(order=(1, 1, 1), seasonal_order=(1, 1, 1, 7))
# data = forecasting.load_data(r'C:\upi_data\master_timeseries_data_new.csv', 'transaction_date', 'revenue', test_size=45)

# forecasting.check_stationarity(data['revenue'])
# forecasting.train_model('revenue')

# forecast_results, conf_int = forecasting.forecast(steps=45)
# metrics = forecasting.evaluate('revenue')

# print("Evaluation Metrics:", metrics)
# forecasting.plot_results('revenue')

from sarima_framework_revenue_daily import SARIMAForecasting
import sys
import os
import pickle
# Add the config folder path to sys.path
config_path = os.path.join(os.path.dirname(__file__), 'config')
sys.path.append(config_path)

# Now import the CONFIG dictionary
from config import CONFIG_sarima_revenue_daily 


def run_pipeline(config):
    # Initialize and run SARIMA model
    forecasting = SARIMAForecasting(
        order=config['sarima_order'], 
        seasonal_order=config['seasonal_order']
    )

    # Load data
    data = forecasting.load_data(
        config['data_path'], 
        config['date_col'], 
        config['target_col'], 
        config['test_size']
    )

    # Check stationarity
    forecasting.check_stationarity(data[config['target_col']])

    # Train model
    forecasting.train_model(config['target_col'])

    # Save model
    with open(config['model_save_path'], 'wb') as f:
        pickle.dump(forecasting, f)
    print(f"Model saved at {config['model_save_path']}")

    # Forecast and evaluate
    forecast_results, conf_int = forecasting.forecast(steps=config['test_size'])
    metrics = forecasting.evaluate(config['target_col'])

    print("Evaluation Metrics:", metrics)

    # Plot results
    forecasting.plot_results(config['target_col'])


if __name__ == '__main__':
    run_pipeline(CONFIG_sarima_revenue_daily)
