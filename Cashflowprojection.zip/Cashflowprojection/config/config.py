# Configuration settings for the SARIMA pipeline

CONFIG_sarima_revenue_daily = {
    'data_path': r'C:\upi_data\master_timeseries_data_new.csv',
    'date_col': 'transaction_date',
    'target_col': 'revenue',
    'test_size': 45,
    'sarima_order': (1, 1, 1),
    'seasonal_order': (1, 1, 1, 7),
    'model_save_path': 'models/sarima_model.pkl'
}


CONFIG_sarima_revenue_monthly = {
    'data_path': r'C:\upi_data\master_timeseries_data_new.csv',
    'date_col': 'transaction_date',
    'target_col': 'revenue',
    'test_size': 6,
    'sarima_order': (1, 1, 1),
    'seasonal_order': (1, 1, 1, 7),
    'model_save_path': 'models/sarima_model.pkl',
    'forecast_comparison_save_path': 'models/Revenue_forecast_comparison_monthly.csv'
}


CONFIG_sarima_expense_daily = {
    'data_path': r'C:\upi_data\master_timeseries_data_new.csv',
    'date_col': 'transaction_date',
    'target_col': 'expense',
    'test_size': 45,
    'sarima_order': (1, 1, 1),
    'seasonal_order': (1, 1, 1, 7),
    'model_save_path': 'models/sarima_model.pkl'
}


CONFIG_sarima_expense_monthly = {
    'data_path': r'C:\upi_data\master_timeseries_data_new.csv',
    'date_col': 'transaction_date',
    'target_col': 'expense',
    'test_size': 6,
    'sarima_order': (1, 1, 1),
    'seasonal_order': (1, 1, 1, 7),
    'model_save_path': 'models/sarima_model.pkl',
    'forecast_comparison_save_path': 'models/Expense_forecast_comparison_monthly.csv'
}